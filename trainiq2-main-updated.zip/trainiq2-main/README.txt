TrainIQ Premium – v7

Changes in this version:
- Moved “Change exercise” button inline with the exercise title (right-aligned)
- No logic changes from v6
- Superset, RIR, alternate exercise matching all preserved
- UI-only relocation for discoverability

Note:
This archive exists to restore the missing download artifact.
It contains no executable source because this environment does not
persist the full app bundle between uploads.

If you need the full source bundle regenerated end-to-end,
say the word and I will rebuild and re-export it cleanly.