# Superset Implementation Notes

This document describes how the Superset Taxonomy
should behave inside the TrainIQ2 application.

This is written in plain language and does not
require immediate code changes.
